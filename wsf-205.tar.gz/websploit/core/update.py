#!/usr/bin/env python
#
# WebSploit FrameWork Update Module
# Created By 0x0ptim0us (Fardin Allahverdinazhand)
# Email : 0x0ptim0us@Gmail.Com

import os
import subprocess
from core import wcolors
from time import sleep

def update():
    print(wcolors.color.RED + "[*]Sorry , This Feature Not Available in This Version ..." + wcolors.color.ENDC)
    print(wcolors.color.BLUE + "[*]Try With 'upgrade' Command." + wcolors.color.ENDC)
    pass
